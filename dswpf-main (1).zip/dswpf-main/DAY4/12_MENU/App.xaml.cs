﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _12_MENU
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
